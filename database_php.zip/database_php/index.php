<?php include "db.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>To-Do List</title>
    <style>
        body {
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #74ebd5 0%, #9face6 100%);
            display: flex;
            justify-content: center;
            align-items: flex-start;
            min-height: 100vh;
            margin: 0;
            padding: 30px;
        }
        .container {
            background: #fff;
            width: 500px;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            padding: 25px;
            animation: fadeIn 0.8s ease-in-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 20px;
        }
        input[type="text"] {
            flex: 1;
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 8px;
            outline: none;
            font-size: 14px;
            transition: border 0.3s;
        }
        input[type="text"]:focus {
            border-color: #74b9ff;
        }
        button {
            padding: 12px 20px;
            background: #6c5ce7;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: 0.3s;
            font-size: 14px;
        }
        button:hover {
            background: #5a4cc9;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th {
            background: #f1f1f1;
            padding: 12px;
            border-radius: 8px 8px 0 0;
            text-align: left;
        }
        td {
            padding: 12px;
            border-bottom: 1px solid #eee;
            font-size: 15px;
        }
        tr:hover {
            background: #fafafa;
        }
        .delete-btn {
            text-decoration: none;
            color: white;
            background: #d63031;
            padding: 8px 14px;
            border-radius: 6px;
            font-size: 13px;
            transition: 0.3s;
        }
        .delete-btn:hover {
            background: #c0392b;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>✅ To-Do List</h1>

        <form action="add.php" method="POST">
            <input type="text" name="task" placeholder="Enter new task..." required>
            <button type="submit">Add</button>
        </form>

        <table>
            <tr>
                <th>ID</th>
                <th>Task</th>
                <th>Action</th>
            </tr>
            <?php
            $result = $conn->query("SELECT * FROM tasks ORDER BY id DESC");
            while($row = $result->fetch_assoc()):
            ?>
            <tr>
                <td><?= $row['id']; ?></td>
                <td><?= htmlspecialchars($row['task']); ?></td>
                <td><a class="delete-btn" href="delete.php?id=<?= $row['id']; ?>">Delete</a></td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>
</html>
